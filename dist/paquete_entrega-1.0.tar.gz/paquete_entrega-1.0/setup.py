from setuptools import setup
setup (
    name = "paquete_entrega",
    version="1.0", 
    description="Segunda pre-entrega", 
    author="Lucas Olhasso",
    author_email="olhassolucas@gmail.com",
    packages=["paquete_entrega"],
)